function refPlayer()
  local ref = {}
  ref.hp = 100
  ref.shape = collider:addPolygon(225, 475, 215, 505, 235, 505)
  ref.update = function(self, dt)
    self.x, self.y = self.shape:center()
    if self.x > 10 and love.keyboard.isDown("a") then
      self.shape:move(-150 * dt, 0)
    elseif self.x < 440 and love.keyboard.isDown("d") then
      self.shape:move(150 * dt, 0)
    end
    if self.y > 45 and love.keyboard.isDown("w") then
      self.shape:move(0, -150 * dt)
    elseif self.y < 535 and love.keyboard.isDown("s") then
      self.shape:move(0, 150 * dt)
    end
    if self.hp <= 0 then
      self.draw = function(self) end
      self.keypressed = function(self, key) end
      self.onCollide = function(self, key) end
      self.time = cTime + 2
      table.remove(player.life, #player.life)
      self.update = function(self, dt)
        if cTime >= self.time and #player.life > 0 then
          local ref = refPlayer()
          self = ref
        end
      end
    end
  end
  ref.draw = function(self)
    love.graphics.setColor(10, 255, 0)
    self.shape:draw("fill")
    love.graphics.setColor(0, 245, 10)
    love.graphics.rectangle("fill", 15, 15, self.hp, 20) -- HP bar
  end
  ref.keypressed = function(self, key) end
  ref.onCollide = function(self, obj)
    obj.hp = 0
  end
  return ref
end